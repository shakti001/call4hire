def test():
    i =1 
    while i<=3:
        print(i)
        break
    else:
        print("print")

test()