from django.apps import AppConfig


class Call4JobempConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'call4jobemp'
