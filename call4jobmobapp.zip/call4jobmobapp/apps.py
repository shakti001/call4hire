from django.apps import AppConfig


class Call4JobmobappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'call4jobmobapp'
